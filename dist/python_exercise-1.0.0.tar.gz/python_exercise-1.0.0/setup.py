from distutils.core import setup

setup(
        name='python_exercise',
        version='1.0.0',
        packages=['.'],
        url='https://github.com/rinoale/python_exercise',
        license='MIT',
        author='rinoale',
        author_email='rinoale@hanmail.net',
        description='Python exercise'
)
