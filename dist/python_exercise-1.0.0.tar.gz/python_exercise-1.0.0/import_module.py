from module_test import human

print(human.sing())
